
d = new Date()
document.writeln("Local date " + d.toLocaleString() + "<br>")
document.writeln("Today is " + d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear() + "<br>")
